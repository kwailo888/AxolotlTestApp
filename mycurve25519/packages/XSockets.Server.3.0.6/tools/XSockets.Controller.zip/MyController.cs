using XSockets.Core.XSocket;
using XSockets.Core.XSocket.Helpers;

namespace $rootnamespace$
{
    public class $safeitemrootname$ : XSocketController
    {
        //Implement/Override your custom actionmethods, events etc in this real-time MVC controller
    }  
}
