using XSockets.Core.Common.Interceptor;
using XSockets.Core.Common.Socket;
using XSockets.Core.Common.Socket.Event.Interface;

namespace $rootnamespace$
{
    /// <summary>
    /// A custom message interceptor.
    /// 
    /// Note: Be sure do use thread safe techniques in interceptors
    /// </summary>
    public class $safeitemrootname$ : IMessageInterceptor
    {
        /// <summary>
        /// Text-message sent TO the server
        /// </summary>
        /// <param name="socket"></param>
        /// <param name="textArgs"></param>
        public void OnMessage(IXSocketController socket, ITextArgs textArgs)
        {
            
        }

        /// <summary>
        /// Binary-message sent TO the server
        /// </summary>
        /// <param name="socket"></param>
        /// <param name="binaryArgs"></param>
        public void OnMessage(IXSocketController socket, IBinaryArgs binaryArgs)
        {
         
        }

        /// <summary>
        /// Text-message sent FROM the server
        /// </summary>
        /// <param name="socket"></param>
        /// <param name="textArgs"></param>
        public void OnSend(IXSocketController socket, ITextArgs textArgs)
        {
            
        }

        /// <summary>
        /// Binary-message sent FROM the server
        /// </summary>
        /// <param name="socket"></param>
        /// <param name="binaryArgs"></param>
        public void OnSend(IXSocketController socket, IBinaryArgs binaryArgs)
        {
            
        }
    }
}
