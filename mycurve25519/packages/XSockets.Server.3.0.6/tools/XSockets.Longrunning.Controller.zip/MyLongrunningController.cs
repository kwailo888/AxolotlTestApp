using XSockets.Core.Common.Globals;
using XSockets.Core.Common.Socket;
using XSockets.Core.XSocket;
using XSockets.Core.XSocket.Helpers;
using XSockets.Plugin.Framework;

namespace $rootnamespace$
{
	[XSocketMetadata("$safeitemrootname$", Constants.GenericTextBufferSize, PluginRange.Internal)]
    public class $safeitemrootname$ : XSocketController
    {
        static $safeitemrootname$()
        {
			//Initialize your long running stuff here  
        }
    }
}
