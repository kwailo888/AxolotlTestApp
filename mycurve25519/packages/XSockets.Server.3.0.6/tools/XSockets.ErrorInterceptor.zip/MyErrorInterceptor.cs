using XSockets.Core.Common.Interceptor;
using XSockets.Core.Common.Socket;
using XSockets.Core.Common.Socket.Event.Arguments;

namespace $rootnamespace$
{
    /// <summary>
    /// A custom error inteceptor.
    /// 
    /// Note: Be sure do use thread safe techniques in interceptors
    /// </summary>
    public class $safeitemrootname$ : IErrorInterceptor
    {
        public void OnError(IXSocketController socket, OnErrorArgs errorArgs)
        {
        }

        public void OnError(OnErrorArgs errorArgs)
        {
        }
    }
}
