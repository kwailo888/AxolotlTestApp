using XSockets.Core.Common.Interceptor;
using XSockets.Core.Common.Socket.Event.Arguments;

namespace $rootnamespace$
{
    /// <summary>
    /// A custom connection interceptor.
    /// 
    /// Note: Be sure do use thread safe techniques in interceptors
    /// </summary>
    public class $safeitemrootname$: IConnectionInterceptor
    {
        public void Connected(OnClientConnectArgs args)
        {
        }

        public void Disconnected(OnClientDisconnectArgs args)
        {         
        }

        public void HandshakeCompleted(OnHandshakeCompleteArgs args)
        {            
        }

        public void HandshakeInvalid(OnHandshakeInvalidArgs args)
        {         
        }
    }
}
