using XSockets.Core.Common.Protocol;
using XSockets.Core.Common.Socket;
using XSockets.Core.Common.Socket.Event.Interface;
using XSockets.Core.XSocket;

namespace $rootnamespace$
{
    /// <summary>
    /// A module that lets you override the default behavior of incomming/outgoing messages
    /// </summary>
    public class $safeitemrootname$: XSocketPipeline
    {
        //Incomming textmessage
        public override void OnMessage(IXSocketController controller, ITextArgs e)
        {
	    //Let the message continue into the server
	    base.OnMessage(controller,e);
        }

        //Outgoing textmessage
        public override ITextArgs OnSend(IXSocketProtocol protocol, ITextArgs e)
        {            
            return base.OnSend(protocol, e);
        }

        //Incomming binarymessage
        public override void OnMessage(IXSocketController controller, IBinaryArgs e)
        {
            //Let the message continue into the server
	    base.OnMessage(controller,e);
        }

        //Outgoing binarymessage
        public override IBinaryArgs OnSend(IXSocketProtocol protocol, IBinaryArgs e)
        {
            return base.OnSend(protocol, e);
        }
    }
}
